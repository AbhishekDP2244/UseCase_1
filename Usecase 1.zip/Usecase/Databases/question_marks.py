import sqlite3
import random

# Subjects and config
subjects = ["Math", "Science", "English", "History", "Computer"]
num_students = 5
num_questions = 7  # Less than 10

# Connect to SQLite database
conn = sqlite3.connect("marks.db")
cursor = conn.cursor()

for subject in subjects:
    table_name = f"question_{subject.lower()}"

    # Drop table if exists for clean rerun (optional)
    cursor.execute(f"DROP TABLE IF EXISTS {table_name};")

    # Create table without ID column
    create_query = f"""
    CREATE TABLE {table_name} (
        Question_ID INTEGER,
        Marks_Scored INTEGER,
        Student_ID INTEGER
    );
    """
    cursor.execute(create_query)

    # Insert marks for each student-question pair
    for student_id in range(1, num_students + 1):
        for question_id in range(1, num_questions + 1):
            marks = random.randint(1, 10)  # Or your desired mark range
            insert_query = f"""
            INSERT INTO {table_name} (Question_ID, Marks_Scored, Student_ID)
            VALUES (?, ?, ?);
            """
            cursor.execute(insert_query, (question_id, marks, student_id))

# Commit changes and close connection
conn.commit()
conn.close()

print("SQLite database 'marks.db' created with 5 subject tables (each with 35 rows).")
