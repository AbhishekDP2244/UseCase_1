import sqlite3

# Subjects
subjects = ["Math", "Science", "English", "History", "Computer"]
subject_tables = [f"question_{sub.lower()}" for sub in subjects]

# Connect to database
conn = sqlite3.connect("marks.db")
cursor = conn.cursor()

# Drop summary table if it exists
cursor.execute("DROP TABLE IF EXISTS student_total_marks;")

# Create summary table
create_query = """
CREATE TABLE student_total_marks (
    Student_ID INTEGER PRIMARY KEY,
    Math INTEGER,
    Science INTEGER,
    English INTEGER,
    History INTEGER,
    Computer INTEGER
);
"""
cursor.execute(create_query)

# Create dictionary to store marks
student_scores = {i: {} for i in range(1, 6)}  # Student_ID: 1 to 5

# Get total per subject for each student
for subject in subjects:
    table_name = f"question_{subject.lower()}"
    cursor.execute(f"""
        SELECT Student_ID, SUM(Marks_Scored) as total
        FROM {table_name}
        GROUP BY Student_ID;
    """)
    results = cursor.fetchall()
    for student_id, total in results:
        student_scores[student_id][subject] = total

# Insert into summary table
for student_id in range(1, 6):
    values = [student_id] + [student_scores[student_id].get(sub, 0) for sub in subjects]
    cursor.execute(f"""
        INSERT INTO student_total_marks (Student_ID, Math, Science, English, History, Computer)
        VALUES (?, ?, ?, ?, ?, ?);
    """, values)

# Commit and close
conn.commit()
conn.close()

print("Summary table 'student_total_marks' created with total marks per student for each subject.")
