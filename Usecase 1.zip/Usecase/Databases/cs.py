import sqlite3
import random

# Connect to the database
conn = sqlite3.connect('subjects.db')
cursor = conn.cursor()

# Updated subject table names
subject_tables = ['Mathematics', 'Physics', 'Chemistry', 'Computer_Science', 'English']

# Step 1: Create subject tables
for table in subject_tables:
    cursor.execute(f'''
    CREATE TABLE IF NOT EXISTS {table} (
        student_id TEXT PRIMARY KEY,
        student_name TEXT,
        hard_level_scored INTEGER,
        medium_level_scored INTEGER,
        easy_level_scored INTEGER,
        total_marks_scored INTEGER
    )
    ''')

# Step 2: Generate realistic scores between 50-100
def generate_student_data():
    students = []
    for i in range(1, 31):
        student_id = f"STU{i:03}"
        student_name = f"Student_{i:02}"

        # Random distribution to hard, medium, and easy
        hard = random.randint(10, 30)
        medium = random.randint(10, 40)
        easy = random.randint(10, 40)
        total = hard+medium+easy
        students.append((student_id, student_name, hard, medium, easy, total))
    return students

# Step 3: Populate each subject table
for table in subject_tables:
    students = generate_student_data()
    cursor.executemany(f'''
    INSERT OR REPLACE INTO {table}
    (student_id, student_name, hard_level_scored, medium_level_scored, easy_level_scored, total_marks_scored)
    VALUES (?, ?, ?, ?, ?, ?)
    ''', students)

# Finalize
conn.commit()
conn.close()
print("✅ Tables updated with marks between 50 and 100, randomly distributed among hard/medium/easy levels.")
