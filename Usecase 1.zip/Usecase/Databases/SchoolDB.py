import sqlite3

# Connect to SQLite database (or create it)
conn = sqlite3.connect('subjects.db')
cursor = conn.cursor()

# Step 1: Create the table
cursor.execute('''
CREATE TABLE IF NOT EXISTS subjects (
    subject_name TEXT,
    subject_id TEXT PRIMARY KEY,
    hard_marks INTEGER,
    medium_marks INTEGER,
    easy_marks INTEGER,
    total_marks INTEGER
)
''')

# Step 2: Insert sample data
data = [
    ("Mathematics", "MATH101", 30, 40, 40, 100),
    ("Physics", "PHYS102", 30, 40, 40, 100),
    ("Chemistry", "CHEM103", 30, 40, 40, 100),
    ("Computer Science", "CS104", 40, 40, 25, 100),
    ("English", "ENG105", 30, 40, 40, 100)
]

cursor.executemany('''
INSERT OR REPLACE INTO subjects 
(subject_name, subject_id, hard_marks, medium_marks, easy_marks, total_marks)
VALUES (?, ?, ?, ?, ?, ?)
''', data)

# Step 3: Fetch and display all rows
cursor.execute("SELECT * FROM subjects")
rows = cursor.fetchall()

print("\nSubjects Table:")
print("| {:<17} | {:<9} | {:<10} | {:<12} | {:<10} | {:<11} |".format(
    "Subject Name", "Subject ID", "Hard Marks", "Medium Marks", "Easy Marks", "Total Marks"))
print("-" * 80)

for row in rows:
    print("| {:<17} | {:<9} | {:<10} | {:<12} | {:<10} | {:<11} |".format(*row))

# Save and close
conn.commit()
conn.close()
