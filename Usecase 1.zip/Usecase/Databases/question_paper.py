import sqlite3
import random

# Subjects and sample concepts for demo purposes
subjects = {
    "Math": ["Algebra", "Geometry", "Trigonometry", "Calculus", "Statistics", "Number Theory", "Probability"],
    "Science": ["Photosynthesis", "Electricity", "Motion", "Atoms", "Magnetism", "Sound", "Light"],
    "English": ["Grammar", "Comprehension", "Vocabulary", "Essay Writing", "Literature", "Tenses", "Idioms"],
    "History": ["Ancient India", "Medieval Europe", "World Wars", "Indian Independence", "Constitution", "Renaissance", "Industrial Revolution"],
    "Computer": ["Loops", "Conditions", "Data Structures", "Algorithms", "Databases", "OOP", "Networking"]
}

difficulty_levels = ["Easy", "Medium", "Hard"]

# Connect to SQLite database
conn = sqlite3.connect("marks.db")
cursor = conn.cursor()

for subject, concepts in subjects.items():
    table_name = f"{subject.lower()}_questions"

    # Drop table if it already exists
    cursor.execute(f"DROP TABLE IF EXISTS {table_name};")

    # Create the question metadata table
    create_query = f"""
    CREATE TABLE {table_name} (
        Question_ID INTEGER,
        Max_Marks INTEGER,
        Concept_Name TEXT,
        Difficulty_Level TEXT
    );
    """
    cursor.execute(create_query)

    # Insert 7 question details
    for question_id in range(1, 8):
        max_marks = 10  # You can randomize if needed
        concept = concepts[question_id - 1]
        difficulty = random.choice(difficulty_levels)
        insert_query = f"""
        INSERT INTO {table_name} (Question_ID, Max_Marks, Concept_Name, Difficulty_Level)
        VALUES (?, ?, ?, ?);
        """
        cursor.execute(insert_query, (question_id, max_marks, concept, difficulty))

# Commit and close
conn.commit()
conn.close()

print("5 metadata tables created for subjects, each with 7 questions and associated details.")
