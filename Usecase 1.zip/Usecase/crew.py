from crewai import Agent, Crew, Process, Task
from crewai.tools.structured_tool import CrewStructuredTool
from crewai.tools.base_tool import Tool
from crewai.project import CrewBase, agent, crew, task
from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit
from langchain_experimental.tools import PythonREPLTool
# from langchain_community_openai import ChatOpenAI
from pydantic import BaseModel
from sqlalchemy import create_engine
from langchain_community.utilities.sql_database import SQLDatabase
from openai import AzureOpenAI
from langchain_openai import AzureOpenAI
from langchain.chat_models import AzureChatOpenAI
from dotenv import load_dotenv
load_dotenv()

endpoint = "https://freshers-ai-hackathon.openai.azure.com/"
model_name = "gpt-4o-mini"
deployment = "ai-hack-5-mnbtr-gpt-4o-mini"

subscription_key = "5fssP309CRrR7RRbpiVMHXVYcc5r1B9LFDFbay8T57LQdSmS8OUDJQQJ99BDAC4f1cMXJ3w3AAABACOGmwEb"
api_version = "2025-01-01-preview"


llm = AzureChatOpenAI(
    deployment_name=deployment,
    openai_api_version=api_version,
    openai_api_base=endpoint,
    openai_api_key=OPENAI_API_KEY
)

@CrewBase
class StudentPerformanceCrew:
    """Personalized Learning & Class Analytics"""
    
    def __init__(self):
        # Path to the SQLite database
        db_path = 'Databases/marks.db'
        db = SQLDatabase.from_uri(f"sqlite:///{db_path}")
        self.dbtools = SQLDatabaseToolkit(db=db, llm = llm).get_tools()
        self.crew_db_tools = []

        # Convert LangChain tools into CrewAI tools
        for tool in self.dbtools:
            crew_tool = Tool.from_langchain(
                CrewStructuredTool.from_function(name=tool.name, func=tool._run, args_schema=tool.args_schema)
            )
            self.crew_db_tools.append(crew_tool)
            print(f"Successfully created tool: {tool.name}")

        # Add Python REPL tool for additional calculations if needed
        python_repl_tool = PythonREPLTool()

        class PythonREPLSchema(BaseModel):
            query: str

        self.code_interpreter = Tool.from_langchain(
            CrewStructuredTool.from_function(
                name=python_repl_tool.name,
                func=python_repl_tool._run,
                args_schema=PythonREPLSchema
            )
        )

    @agent
    def subject_report_agent(self) -> Agent:
        """Agent to generate subject-level performance reports for all students."""
        return Agent(
            config=self.agents_config['subject_report_agent'],
            verbose=True
        )

    @agent
    def class_learning_strategy_agent(self) -> Agent:
        """Agent to generate class-level learning strategies for a subject."""
        return Agent(
            config=self.agents_config['class_learning_strategy_agent'],
            verbose=True
        )

    @agent
    def student_feedback_agent(self) -> Agent:
        """Agent to generate individual feedback based on student performance."""
        return Agent(
            config=self.agents_config['student_feedback_agent'],
            verbose=True
        )

    @agent
    def student_learning_strategy_agent(self) -> Agent:
        """Agent to generate personalized learning strategies for each student."""
        return Agent(
            config=self.agents_config['student_learning_strategy_agent'],
            verbose=True
        )

    @task
    def generate_subject_report(self) -> Task:
        """Task to generate a subject-level report for all students."""
        return Task(
            config=self.tasks_config['generate_subject_report']
        )

    @task
    def generate_class_learning_strategy(self) -> Task:
        """Task to create a class-wide strategy for improving subject performance."""
        return Task(
            config=self.tasks_config['generate_class_learning_strategy']
        )

    @task
    def generate_student_feedback(self) -> Task:
        """Task to analyze student marks and create feedback reports."""
        return Task(
            config=self.tasks_config['generate_student_feedback']
        )

    @task
    def generate_student_learning_strategy(self) -> Task:
        """Task to generate personalized learning strategies across all subjects."""
        return Task(
            config=self.tasks_config['generate_student_learning_strategy']
        )

    @crew
    def crew(self) -> Crew:
        """Assembles the full performance analysis and learning crew."""
        return Crew(
            agents=[
                self.subject_report_agent(),
                self.class_learning_strategy_agent(),
                self.student_feedback_agent(),
                self.student_learning_strategy_agent()
            ],
            tasks=[
                self.generate_subject_report(),
                self.generate_class_learning_strategy(),
                self.generate_student_feedback(),
                self.generate_student_learning_strategy()
            ],
            process=Process.sequential,
            verbose=True
        )