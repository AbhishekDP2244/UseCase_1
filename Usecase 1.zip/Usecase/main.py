from crew import StudentPerformanceCrew
from dotenv import load_dotenv
load_dotenv()
def main():
    # """
    # Main function to run the Order Tracking Crew.
    # Extracts order details, retrieves tracking information, and generates a response.
    # """
    # Load environment variables
    # load_dotenv()
    
    # Create order data dictionary with sample values
    order_data = {
        "input": "Generate report or feedback of student ID 1"  # Example user query
    }
    
    # Initialize and run the crew
    crew = StudentPerformanceCrew().crew()
    result = crew.kickoff(inputs=order_data)
    
    print("\nOrder Tracking Response:")
    print(result)

if __name__ == "__main__":
    main()
